import greenfoot.*;
public class Mario extends Actor
{
    int gravity = 1; 
    int velocity = 0; 
    long lastTime;
    int Lives = 3;
    String LastPressed = "right";
    boolean HaveHammer = false;
    long hammertimer;
    long hitTimer;
    int animationState = 0; 

    public void act() { 
        getWorld().showText("Lives : "+ Lives +"",1450, 50); 
         if (Lives <= 0) { 
            MarioDied();
            if(System.currentTimeMillis() - hitTimer < 1000){
                    animationState = (animationState+1)%4;
            }
            else{
                setImage("mariodead5.png");
                getWorld().showText("GAME OVER", 750, 600);
                Greenfoot.stop();
             }
        }
        if (Lives > 0) { 
            if (isTouching (flameEnemy.class)){
                Lives = Lives-Lives;
            }
            if (isTouching (ladder.class)) { 
                if (Greenfoot.isKeyDown("up")) {
                    setLocation(getX(), getY() - 2); 
                } else { 
                    setLocation(getX(), getY()); 
                } 
                if (Greenfoot.isKeyDown("down")) {
                    setLocation(getX(), getY() + 2); 
                } else { 
                    setLocation(getX(), getY()); 
                } 
            } else { 
                velocity += gravity; 
                setLocation(getX(), getY() + velocity);  
            } 

            if (velocity > 0) { // this whole block is just collision detection for the floor below mario 
                while (isTouching(Floor.class)) { 
                    velocity = 0; 
                    setLocation(getX(), getY() - 1); // takes current mario location and - 1 because that gets him unstuck from the floor below
                    if(Greenfoot.isKeyDown("up")) {
                        velocity = - 15;
                        if(LastPressed.equals("left")){
                            setImage("marioJumpL.png");
                        }
                        else if(LastPressed.equals("right")){
                            setImage("marioJumpR.png");
                        }
                    }
                } 

            } 

            if (velocity <= 0 && !isTouching(ladder.class)){ // this whole block is just collision detection for the floor above mario

                while(isTouching(Floor.class))
                {
                    velocity = 0;
                    setLocation(getX(), getY() + 1);
                }

            } 

            if (Greenfoot.isKeyDown("right")) { // Mario right movement block 
                LastPressed = "right";
                move(9);
                if(System.currentTimeMillis() - lastTime > 100){
                    animationState = (animationState+1)%5;
                    lastTime = System.currentTimeMillis();
                }
                MarioMovmentRight();
            } else if(Greenfoot.isKeyDown("left")) { // Mario left Movement block 
                LastPressed = "left";
                move(-9); 
                if(System.currentTimeMillis() - lastTime > 100){
                    animationState = (animationState+1)%5;
                    lastTime = System.currentTimeMillis();
                } 
                MarioMovmentleft();
            } else { // still image block
                if(!HaveHammer){ // idle mario image block
                    if(LastPressed.equals("left")){
                        setImage("Mario-Idle-Left.png");
                    }
                    else if(LastPressed.equals("right")){
                        setImage("Mario-Idle-Right.png");
                    }
                }  else{
                    if(LastPressed.equals("left")){
                        setImage("marioHamUpL2.png");
                    }
                    else if(LastPressed.equals("right")){
                        setImage("marioHamUpR2.png");
                    }
                }
            }

            if(isTouching(Hammer.class)){
                hammertimer = System.currentTimeMillis();
                HaveHammer = true;
            }

            if(isTouching(Barrel.class)){
                removeTouching(Barrel.class);
                hitTimer = System.currentTimeMillis();
                if(HaveHammer == false){
                    Lives = Lives - 1;
                }
                if (Lives <= 0) { 
                    if(System.currentTimeMillis() - hitTimer < 1000){
                        animationState = (animationState+1)%4;
                    } 
                    MarioDied();
                } 
            } 
            if(HaveHammer){
                if(System.currentTimeMillis() - hammertimer > 5000){
                    HaveHammer = false;
                }
            }
        } 
    } 

    public void MarioMovmentRight(){
        if (!HaveHammer) {
            switch (animationState) {
                case 0:
                    setImage("marioR1.png");
                    break;
                case 1:
                    setImage("marioR2.png");
                    break;
                case 2:
                    setImage("marioR3.png");
                    break;
                case 3:
                    setImage("marioR2.png");
                    break;
                case 4:
                    setImage("marioR1.png");
                    break;
            }
        } else {
            switch (animationState) {
                case 0:
                    setImage("marioHamUpR1.png");
                    break;
                case 1:
                    setImage("marioHamDR1.png");
                    break;
                case 2:
                    setImage("marioHamUpR2.png");
                    break;
                case 3:
                    setImage("marioHamDR2.png");
                    break;
            }
        }

    }

    public void MarioMovmentleft(){
        if (!HaveHammer) {
            switch (animationState) {
                case 0:
                    setImage("marioL1.png");
                    break;
                case 1:
                    setImage("marioL2.png");
                    break;
                case 2:
                    setImage("marioL3.png");
                    break;
                case 3:
                    setImage("marioL2.png");
                    break;
                case 4:
                    setImage("marioL1.png");
                    break;
            }
        } else {
            switch (animationState) {
                case 0:
                    setImage("marioHamUpL1.png");
                    break;
                case 1:
                    setImage("marioHamDL1.png");
                    break;
                case 2:
                    setImage("marioHamUpL2.png");
                    break;
                case 3:
                    setImage("marioHamDL2.png");
                    break;
            }
        }
    }

    public void MarioDied() {
        switch(animationState) {
            case 0:
                setImage("mariodead1.png");
                break;
            case 1:
                setImage("mariodead2.png");
                break;
            case 2:
                setImage("mariodead3.png");
                break;
            case 3:
                setImage("mariodead1.png");
                break;
            default:
                // Handle default case if needed
                break;
        }
    }

} 
