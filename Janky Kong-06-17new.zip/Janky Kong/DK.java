import greenfoot.*;
public class DK extends Actor
{
    long lastTime;
    GreenfootImage dkIdle1 = new GreenfootImage("donkey-kong_standing.png");
    GreenfootImage dkThrow = new GreenfootImage("Donkey_Kong_Classic_NES_Artwork.png");
    GreenfootImage dkIdle2 = new GreenfootImage("donkeyIdle2.png");
    boolean spawnbarrel = false;
    long throwtimer;
    public void act() 
    {
        if(isTouching(Mario.class))
        {
            Greenfoot.setWorld(new Finish());
            Greenfoot.stop();
        }
        if(System.currentTimeMillis() - lastTime > 2500)
        {
            //setImage(dkThrow);
             if(spawnbarrel){
                throwtimer = System.currentTimeMillis();
                DKThrow();
            }
            else{
                dkThrow.scale(100, 100);
                getWorld().addObject(new Barrel(), getX(), getY()-2);
                lastTime = System.currentTimeMillis();
            }
        } 
        //DKIdle();
    } 
    public void DKIdle()
        {
            if (System.currentTimeMillis() - lastTime > 800 ){
                setImage(dkIdle1);
            } 
            if (System.currentTimeMillis() - lastTime > 1000){
                setImage(dkIdle2);
            } 
            if (System.currentTimeMillis() - lastTime > 1200 ){
                setImage(dkIdle1);
            } 
            if (System.currentTimeMillis() - lastTime > 1400){
                setImage(dkIdle2);
                throwtimer = System.currentTimeMillis();
            } 
        }
    public void DKThrow()
        {
             if (System.currentTimeMillis() - throwtimer > 1500 ){
                setImage("DKThrow3.png");
                dkThrow.scale(100, 100);
                spawnbarrel = true;
            } 
            else if (System.currentTimeMillis() - throwtimer > 1000){
                setImage("DKThrow2.png");
                dkThrow.scale(100, 100);
            }
            else if (System.currentTimeMillis() - throwtimer > 500 ){
                setImage("DKThrow1.png");
                dkThrow.scale(100, 100);
            }  
        }
}
