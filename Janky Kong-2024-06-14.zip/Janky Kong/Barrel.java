import greenfoot.*;
/**
 * Write a description of class Barrel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Barrel extends Actor
{
    int animationState  = 0;
    int timer = 500;
    long lastTime = 0;
    boolean inAir = false;
    public void act() 
    {
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        } else{
          animationState = (int)((System.currentTimeMillis()/250)%2);
          FallingAnimation();
          setLocation(getX(), getY() + 3);   
          while(isTouching(Floor2.class))
          {
            setLocation(getX() - 3, getY() - 3);
            setImage("Barrel.png");
            animationState = (int)((System.currentTimeMillis()/250)%4);
            RollingAnimation();
           }
          while(isTouching(Floor.class))
          {
                setLocation(getX() + 3, getY() - 3);
                setImage("Barrel.png"); 
                animationState = (int)((System.currentTimeMillis()/250)%4);
                RollingAnimation();
          }
        }
    }
    public void FallingAnimation(){
        if(animationState == 0){
             setImage("BarrelF1.png");
        }
        if(animationState == 2){
             setImage("BarrelF1.png");
        }
    }
     public void RollingAnimation(){
        if(animationState == 0){
             setImage("Barrel1.png");
        }
        if(animationState == 1){
             setImage("Barrel2.png");
        }
        if(animationState == 2){
             setImage("Barrel3.png");
        }
        if(animationState == 3){
             setImage("Barrel4.png");
        }
    }
    public void ExplodeAnimation(){ 
        if(animationState == 0){
             setImage("Explode1.png");
        }
        if(animationState == 1){
             setImage("Explode2.png");
        }
        if(animationState == 2){
             setImage("Explode3.png");
        }
        if(animationState == 3){
             setImage("Explode4.png");
        }
    }    
}
 