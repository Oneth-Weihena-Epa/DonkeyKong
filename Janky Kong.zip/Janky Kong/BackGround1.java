import greenfoot.*;

/**
 * Write a description of class BackGround1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackGround1 extends World
{

    /**
     * Constructor for objects of class BackGround1.
     * 
     */
    public BackGround1()
    {    
        super(1500, 1000, 1); 
        
         addObject(new Floor(), 125, 219);
        addObject(new Floor(), 375, 219);
        addObject(new Floor(), 625, 219);
        addObject(new Floor(), 875, 219);
        addObject(new Floor2(), 625, 500);
        addObject(new Floor2(), 875, 500);
        addObject(new Floor2(), 1125, 500);
        addObject(new Floor2(), 1375, 500);
        addObject(new Floor(), 125, 780);
        addObject(new Floor(), 375, 790);
        addObject(new Floor(), 625, 800);
        addObject(new Floor(), 875, 810);
        addObject(new Floor2(), 125, 1000);
        addObject(new Floor2(), 375, 1000);
        addObject(new Floor2(), 625, 1000);
        addObject(new Floor2(), 875, 1000);
        addObject(new Floor2(), 1125, 1000);
        addObject(new Floor2(), 1375, 1000);
        
        addObject(new ladder(), 950, 790);
        addObject(new ladder(), 950, 810); 
        addObject(new ladder(), 950, 860);
        addObject(new ladder(), 950, 910);
         addObject(new ladder(), 950, 960);
        
        addObject(new DK(), 200, 150);
        addObject(new Mario(), 125, 940);
        addObject(new Hammer(), 125, 640);
        
        
    }
}
