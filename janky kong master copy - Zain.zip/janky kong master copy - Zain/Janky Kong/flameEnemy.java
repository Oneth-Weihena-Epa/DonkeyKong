import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class flameEnemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class flameEnemy extends Actor
{
    /**
     * Act - do whatever the flameEnemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    //go up for 1 second and to the side
    //go down after that at same speed for 1 second
    long timer;
    int grav = 1;
    private int velocityY = 0; 
    private int velocityX = 0;
    private int jumpVelocity = -9;
    private int sideVelocity = 2;
    int animationState = 1;
    boolean onGround = false;
    GreenfootImage right = new GreenfootImage("flameRight.png");
    GreenfootImage left = new GreenfootImage("flameLeft.png");
    public void act()
    {
            if(isTouching(ladder.class)){
                
                sideVelocity = -sideVelocity;
                right.mirrorHorizontally();
                setImage(right);
            }
            jump();
            gravity();
            move();

    }
    
    public void jump(){
        if(onGround == true){
          velocityY = jumpVelocity;  
          velocityX = 0;
          onGround = false;
        }
    }
    
    public void gravity(){
        if(onGround == false){
            velocityY += grav;
            velocityX = sideVelocity;
            if(isTouching(Floor.class)||isTouching(Floor2.class)){
                onGround = true;
            }
            if(isTouching(ladder.class)){
                setLocation(getX(), getY()-200);
            }
        }
    }
    public void move(){
        setLocation(getX() + velocityX, getY()+velocityY);
    }
}
