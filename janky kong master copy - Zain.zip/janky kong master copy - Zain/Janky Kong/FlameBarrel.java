import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FlameBarrel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlameBarrel extends Actor
{
    /**
     * Act - do whatever the FlameBarrel wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    boolean onFire = false; 
    GreenfootImage barrelFire = new GreenfootImage("BarrelOnFire.png");
    public void act()
    {
        if(isTouching(Barrel.class)){
            if(onFire == false){
                setLocation(getX(), getY() - 33);
                getWorld().addObject(new flameEnemy(), getX(), getY()+75);
            }
            onFire = true;
        }
        if(onFire){
            setImage(barrelFire);
        }
    }
}
