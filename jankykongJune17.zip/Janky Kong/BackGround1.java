import greenfoot.*;

/**
 * Write a description of class BackGround1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackGround1 extends World
{

    /**
     * Constructor for objects of class BackGround1.
     * 
     */
    public BackGround1()
    {    
        super(1500, 1000, 1); 
        addObject(new Floor(), 50, 270);
        addObject(new Floor(), 300, 280);
        addObject(new Floor(), 550, 290);
        addObject(new Floor(), 800, 300);
        addObject(new Floor(), 1050, 310);
        addObject(new Floor(), 1300, 320);

        addObject(new Floor2(), 225, 580);
        addObject(new Floor2(), 475, 570);
        addObject(new Floor2(), 725, 560);
        addObject(new Floor2(), 975, 550);
        addObject(new Floor2(), 1225, 540);
        addObject(new Floor2(), 1475, 530);

        addObject(new Floor(), -25, 760);
        addObject(new Floor(), 225, 770);
        addObject(new Floor(), 475, 780);
        addObject(new Floor(), 725, 790);
        addObject(new Floor(), 975, 800);
        addObject(new Floor(), 1225, 810);

        addObject(new Floor2(), 125, 1000);
        addObject(new Floor2(), 375, 1000);
        addObject(new Floor2(), 625, 1000);
        addObject(new Floor2(), 875, 1000);
        addObject(new Floor2(), 1125, 1000);
        addObject(new Floor2(), 1375, 1000);

        addObject(new ladder(), 1290, 810); 
        addObject(new ladder(), 1290, 860);
        addObject(new ladder(), 1290, 910);
        addObject(new ladder(), 1290, 960);

        addObject(new ladder(), 220, 580); 
        addObject(new ladder(), 220, 630);
        addObject(new ladder(), 220, 680);
        addObject(new ladder(), 220, 730);
        
        addObject(new ladder(), 1290, 320); 
        addObject(new ladder(), 1290, 370);
        addObject(new ladder(), 1290, 420);
        addObject(new ladder(), 1290, 470);
        addObject(new ladder(), 1290, 520);

        addObject(new DK(), 260, 205);
        addObject(new Mario(), 125, 945);
        addObject(new Hammer(), 1350, 750);

    }
}
