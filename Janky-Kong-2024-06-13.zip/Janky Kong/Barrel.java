import greenfoot.*;
/**
 * Write a description of class Barrel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Barrel extends Actor
{
    GreenfootImage Barrel = new GreenfootImage ("Barrel.png"); 
    int animationState  = 0;
    int timer = 500;
    long lastTime = 0;
    boolean inAir = false;
    public void act() 
    {
        setImage(Barrel);
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        } else{
          animationState = (int)((System.currentTimeMillis()/250)%2);
          FallingAnimation();
          setLocation(getX(), getY() + 3);      
          while(isTouching(Floor2.class))
          {
            setLocation(getX() - 3, getY() - 3);
            setImage("Barrel.png");
            turn(-1);
            
           }
        }
        while(isTouching(Floor.class))
        {
            setLocation(getX() + 3, getY() - 3);
            setImage("Barrel.png"); 
            turn(1);
        }
    }
    public void FallingAnimation(){
        if(animationState == 0){
             setImage("BarrelF1.png");
        }
        if(animationState == 2){
             setImage("BarrelF1.png");
        }
    }
}
 